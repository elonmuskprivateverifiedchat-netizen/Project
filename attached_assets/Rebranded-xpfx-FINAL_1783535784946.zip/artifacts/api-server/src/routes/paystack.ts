/**
 * Paystack Payment Route
 *
 * Handles Paystack payment initiation and webhook verification.
 * Follows the exact same pattern as artifacts/api-server/src/routes/moonpay.ts.
 *
 * Endpoints:
 *   POST /paystack/initiate   — creates a Paystack transaction and returns the
 *                               authorization URL for the user to complete payment
 *   POST /paystack/webhook    — verifies Paystack's HMAC-SHA512 signature and
 *                               credits the user's wallet on successful payment
 *
 * Required env vars:
 *   PAYSTACK_SECRET_KEY   — from dashboard.paystack.com → Settings → API Keys
 *   PAYSTACK_PUBLIC_KEY   — from dashboard.paystack.com → Settings → API Keys
 *
 * If PAYSTACK_SECRET_KEY is not set, all routes return 503 with a clear message.
 */

import { Router, type Request, type Response } from "express";
import { createHmac, timingSafeEqual } from "node:crypto";
import { requireAuth } from "../lib/session.js";
import { logger } from "../lib/logger.js";
import { getStore } from "../lib/store.js";
import { logActivity } from "../lib/audit.js";

const router = Router();

const PAYSTACK_API = "https://api.paystack.co";

// Guard: if no Paystack key, disable all routes gracefully
function requirePaystackKey(req: Request, res: Response, next: () => void) {
  if (!process.env.PAYSTACK_SECRET_KEY) {
    logger.warn("[paystack] PAYSTACK_SECRET_KEY not configured — route unavailable");
    res.status(503).json({
      error: "Paystack integration is not configured on this server.",
    });
    return;
  }
  next();
}

// ── POST /paystack/initiate ───────────────────────────────────────────────────
// Creates a Paystack payment initialization and returns the checkout URL.
// The client redirects the user to authorization_url to complete payment.
router.post(
  "/initiate",
  requireAuth,
  requirePaystackKey,
  async (req: Request, res: Response) => {
    try {
      const userId = (req as any).userId as string;
      const { amount, currency = "NGN", email } = req.body as {
        amount: number;
        currency?: string;
        email?: string;
      };

      if (!amount || amount <= 0) {
        res.status(400).json({ error: "amount must be a positive number" });
        return;
      }

      const store = getStore();
      const user = store.users.get(userId);
      if (!user) {
        res.status(404).json({ error: "User not found" });
        return;
      }

      const userEmail = email ?? user.email;
      // Paystack expects amount in kobo (NGN × 100) or cents (USD × 100)
      const amountInSmallestUnit = Math.round(amount * 100);

      const response = await fetch(`${PAYSTACK_API}/transaction/initialize`, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${process.env.PAYSTACK_SECRET_KEY}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          email: userEmail,
          amount: amountInSmallestUnit,
          currency: currency.toUpperCase(),
          metadata: {
            userId,
            platform: "xpressprofx",
          },
        }),
      });

      const data = (await response.json()) as {
        status: boolean;
        data?: {
          authorization_url: string;
          access_code: string;
          reference: string;
        };
        message?: string;
      };

      if (!data.status || !data.data) {
        logger.error({ userId, message: data.message }, "[paystack] Initiation failed");
        res.status(502).json({ error: data.message ?? "Paystack initiation failed" });
        return;
      }

      logger.info(
        { userId, reference: data.data.reference, amount, currency },
        "[paystack] Transaction initialized",
      );

      res.json({
        authorization_url: data.data.authorization_url,
        reference: data.data.reference,
      });
    } catch (err) {
      logger.error({ err: (err as Error).message }, "[paystack] Initiate error");
      res.status(500).json({ error: "Internal server error" });
    }
  },
);

// ── POST /paystack/webhook ────────────────────────────────────────────────────
// Receives Paystack event notifications.
// IMPORTANT: must be registered BEFORE any body-parser JSON middleware,
// or use express.raw() to preserve the raw body for signature verification.
// In app.ts, this route must receive the raw Buffer body.
router.post("/webhook", async (req: Request, res: Response) => {
  const signature = req.headers["x-paystack-signature"] as string | undefined;

  if (!signature) {
    logger.warn("[paystack/webhook] Missing signature header");
    res.status(400).json({ error: "Missing signature" });
    return;
  }

  if (!process.env.PAYSTACK_SECRET_KEY) {
    res.status(503).json({ error: "Paystack not configured" });
    return;
  }

  try {
    // Verify HMAC-SHA512 signature over raw body
    // The raw body must be preserved in app.ts using express.raw()
    const rawBody: Buffer = (req as any).rawBody;
    if (!rawBody) {
      logger.error("[paystack/webhook] rawBody not available — check app.ts middleware");
      res.status(500).json({ error: "Raw body not available" });
      return;
    }

    const expectedSig = createHmac("sha512", process.env.PAYSTACK_SECRET_KEY)
      .update(rawBody)
      .digest("hex");

    const expectedBuf = Buffer.from(expectedSig, "utf8");
    const receivedBuf = Buffer.from(signature, "utf8");

    if (
      expectedBuf.length !== receivedBuf.length ||
      !timingSafeEqual(expectedBuf, receivedBuf)
    ) {
      logger.warn("[paystack/webhook] Invalid signature — rejected");
      res.status(401).json({ error: "Invalid signature" });
      return;
    }

    // Signature valid — parse the event
    const event = JSON.parse(rawBody.toString("utf8")) as {
      event: string;
      data: {
        reference: string;
        amount: number;
        currency: string;
        status: string;
        metadata?: { userId?: string };
      };
    };

    logger.info({ event: event.event, reference: event.data.reference }, "[paystack/webhook] Event received");

    // Handle charge.success — credit the user's wallet
    if (event.event === "charge.success" && event.data.status === "success") {
      const userId = event.data.metadata?.userId;
      if (!userId) {
        logger.warn({ reference: event.data.reference }, "[paystack/webhook] No userId in metadata");
        res.status(200).json({ received: true });
        return;
      }

      // Convert from smallest unit (kobo/cents) back to main unit
      const amountInMainUnit = event.data.amount / 100;

      const store = getStore();
      const user = store.users.get(userId);
      if (!user) {
        logger.warn({ userId }, "[paystack/webhook] User not found for credit");
        res.status(200).json({ received: true });
        return;
      }

      // Credit the user's main wallet
      const mainWallet = store.wallets.get(`${userId}:main`);
      if (mainWallet) {
        mainWallet.balance = (mainWallet.balance ?? 0) + amountInMainUnit;
        store.wallets.set(`${userId}:main`, mainWallet);
      }

      // Log the deposit activity
      await logActivity({
        userId,
        action: "deposit",
        details: {
          provider: "paystack",
          reference: event.data.reference,
          amount: amountInMainUnit,
          currency: event.data.currency,
        },
      });

      logger.info(
        { userId, amount: amountInMainUnit, currency: event.data.currency, reference: event.data.reference },
        "[paystack/webhook] Wallet credited",
      );
    }

    res.status(200).json({ received: true });
  } catch (err) {
    logger.error({ err: (err as Error).message }, "[paystack/webhook] Processing error");
    // Always return 200 to Paystack to prevent retries on our processing errors
    res.status(200).json({ received: true });
  }
});

export default router;
