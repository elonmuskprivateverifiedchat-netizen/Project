/**
 * FX Rate Poller Job
 *
 * Fetches live exchange rates from Frankfurter API (free, no key required)
 * and caches them in Redis with a 90-second TTL.
 *
 * The API server's quote endpoint reads from this Redis cache instead of
 * making a live API call on every request — keeps quotes fast and avoids
 * rate limits on the upstream provider.
 *
 * Redis key format: fx:rate:EURUSD → { rate, timestamp, provider }
 */

import type { Job } from "bullmq";
import Redis from "ioredis";
import pino from "pino";

const logger = pino({ level: process.env.LOG_LEVEL ?? "info" });

const redis = new Redis(process.env.REDIS_URL ?? "redis://localhost:6379", {
  maxRetriesPerRequest: 3,
});

const CACHE_TTL_SECONDS = 90;
const FRANKFURTER_URL = "https://api.frankfurter.app/latest";

// Supported pairs — base currencies to poll
const BASE_CURRENCIES = ["USD", "EUR", "GBP", "BTC", "ETH"];

export async function processFxRateJob(job: Job): Promise<void> {
  const pairs: string[] = job.data.pairs ?? [];
  logger.info({ jobId: job.id, pairs }, "[fx-poller] Polling FX rates");

  // Group pairs by base currency for efficient API calls
  const byBase: Record<string, string[]> = {};
  for (const pair of pairs) {
    const base = pair.slice(0, 3);
    const quote = pair.slice(3);
    if (!byBase[base]) byBase[base] = [];
    byBase[base]!.push(quote);
  }

  let cached = 0;
  let failed = 0;

  for (const [base, quotes] of Object.entries(byBase)) {
    try {
      const url = `${FRANKFURTER_URL}?base=${base}&symbols=${quotes.join(",")}`;
      const res = await fetch(url);

      if (!res.ok) {
        logger.warn({ base, status: res.status }, "[fx-poller] API returned non-200");
        failed++;
        continue;
      }

      const data = (await res.json()) as {
        rates: Record<string, number>;
        date: string;
      };

      for (const [quote, rate] of Object.entries(data.rates)) {
        const key = `fx:rate:${base}${quote}`;
        const value = JSON.stringify({
          rate,
          timestamp: Date.now(),
          provider: "frankfurter",
          date: data.date,
        });
        await redis.setex(key, CACHE_TTL_SECONDS, value);
        cached++;
      }
    } catch (err) {
      logger.error({ base, err: (err as Error).message }, "[fx-poller] Failed to fetch rates");
      failed++;
    }
  }

  logger.info({ cached, failed }, "[fx-poller] Rate poll complete");
}
