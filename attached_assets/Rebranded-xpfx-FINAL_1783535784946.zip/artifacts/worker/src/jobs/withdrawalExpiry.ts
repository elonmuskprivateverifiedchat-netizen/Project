/**
 * Withdrawal Expiry Job
 *
 * Checks for withdrawal requests that have passed their gas fee deadline
 * and marks them as expired, refunding the amount from pendingBalance
 * back to the user's available balance.
 *
 * This mirrors the same logic in artifacts/api-server/src/lib/sweeper.ts
 * but runs as a BullMQ job (for Docker deployments with Redis) instead of
 * a setInterval in the API server process.
 *
 * In Docker mode: this worker handles expiry.
 * In non-Docker mode: sweeper.ts handles it in-process.
 * Both can run simultaneously safely — the DB update is idempotent.
 */

import type { Job } from "bullmq";
import pino from "pino";

const logger = pino({ level: process.env.LOG_LEVEL ?? "info" });

export async function processWithdrawalExpiryJob(job: Job): Promise<void> {
  const databaseUrl = process.env.DATABASE_URL;

  if (!databaseUrl) {
    logger.warn("[withdrawal-expiry] DATABASE_URL not set — skipping expiry check");
    return;
  }

  try {
    // Dynamic import to avoid bundling the full DB stack into the worker
    // The worker connects to the same Postgres database as the API server
    const { drizzle } = await import("drizzle-orm/node-postgres");
    const pg = await import("pg");
    const { sql } = await import("drizzle-orm");

    const pool = new pg.default.Pool({ connectionString: databaseUrl, max: 2 });
    const db = drizzle(pool);

    // Expire withdrawals past their deadline — same query as sweeper.ts
    // Uses a raw SQL update for simplicity; schema is owned by lib/db
    const result = await db.execute(sql`
      UPDATE withdrawals
      SET
        status = 'expired',
        updated_at = NOW()
      WHERE
        status = 'awaiting_gas_fee'
        AND gas_fee_deadline < NOW()
      RETURNING id, user_id, amount
    `);

    const expired = result.rows ?? [];

    if (expired.length > 0) {
      logger.info({ count: expired.length }, "[withdrawal-expiry] Expired withdrawals found — refunding");

      // Refund pendingBalance back to available balance for each expired withdrawal
      for (const row of expired) {
        await db.execute(sql`
          UPDATE wallets
          SET
            pending_balance = GREATEST(pending_balance - ${row.amount}, 0),
            balance = balance + ${row.amount},
            updated_at = NOW()
          WHERE
            user_id = ${row.user_id}
            AND type = 'main'
        `);

        logger.info(
          { withdrawalId: row.id, userId: row.user_id, amount: row.amount },
          "[withdrawal-expiry] Refunded expired withdrawal",
        );
      }
    } else {
      logger.debug("[withdrawal-expiry] No expired withdrawals found");
    }

    await pool.end();
  } catch (err) {
    logger.error({ err: (err as Error).message }, "[withdrawal-expiry] Job failed");
    throw err; // Let BullMQ retry
  }
}
