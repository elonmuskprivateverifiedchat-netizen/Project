/**
 * Email Queue Job
 *
 * Processes email jobs queued by the API server.
 * Uses the same three-tier fallback chain as artifacts/api-server/src/lib/email.ts:
 *   1. SendGrid (if SENDGRID_API_KEY is set)
 *   2. SMTP (if SMTP_HOST + SMTP_USER + SMTP_PASS are set)
 *   3. Console log only (development fallback)
 *
 * Job data shape:
 *   { to, subject, text?, html? }
 */

import type { Job } from "bullmq";
import pino from "pino";

const logger = pino({ level: process.env.LOG_LEVEL ?? "info" });

export interface EmailJobData {
  to: string;
  subject: string;
  text?: string;
  html?: string;
}

export async function processEmailJob(job: Job<EmailJobData>): Promise<void> {
  const { to, subject, text, html } = job.data;

  if (!to || !subject) {
    throw new Error("Email job missing required fields: to, subject");
  }

  // Tier 1: SendGrid
  if (process.env.SENDGRID_API_KEY) {
    await sendViaSendGrid({ to, subject, text, html });
    logger.info({ to, subject }, "[email-queue] Sent via SendGrid");
    return;
  }

  // Tier 2: SMTP
  if (process.env.SMTP_HOST && process.env.SMTP_USER && process.env.SMTP_PASS) {
    await sendViaSMTP({ to, subject, text, html });
    logger.info({ to, subject }, "[email-queue] Sent via SMTP");
    return;
  }

  // Tier 3: Console fallback (development only)
  logger.warn(
    { to, subject },
    "[email-queue] No email provider configured — logging only (set SENDGRID_API_KEY or SMTP_* vars)",
  );
  console.log(`\n📧 EMAIL (not sent — no provider configured)\nTo: ${to}\nSubject: ${subject}\n${text ?? html ?? ""}\n`);
}

async function sendViaSendGrid(opts: EmailJobData): Promise<void> {
  const res = await fetch("https://api.sendgrid.com/v3/mail/send", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${process.env.SENDGRID_API_KEY}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      personalizations: [{ to: [{ email: opts.to }] }],
      from: { email: process.env.SMTP_FROM ?? "noreply@xpressprofx.com" },
      subject: opts.subject,
      content: [
        opts.html
          ? { type: "text/html", value: opts.html }
          : { type: "text/plain", value: opts.text ?? opts.subject },
      ],
    }),
  });

  if (!res.ok) {
    const body = await res.text();
    throw new Error(`SendGrid error ${res.status}: ${body}`);
  }
}

async function sendViaSMTP(opts: EmailJobData): Promise<void> {
  // Dynamic import — nodemailer is an optional dep, not installed by default
  // Add "nodemailer" to artifacts/worker/package.json dependencies if SMTP is needed
  try {
    const nodemailer = await import("nodemailer");
    const transporter = nodemailer.default.createTransport({
      host: process.env.SMTP_HOST,
      port: parseInt(process.env.SMTP_PORT ?? "587"),
      secure: process.env.SMTP_PORT === "465",
      auth: {
        user: process.env.SMTP_USER,
        pass: process.env.SMTP_PASS,
      },
    });

    await transporter.sendMail({
      from: process.env.SMTP_FROM ?? process.env.SMTP_USER,
      to: opts.to,
      subject: opts.subject,
      text: opts.text,
      html: opts.html,
    });
  } catch (err) {
    throw new Error(
      `SMTP send failed: ${(err as Error).message}. ` +
      `If nodemailer is not installed, run: npm install nodemailer -w @workspace/worker`,
    );
  }
}
